CREATE TABLE IF NOT EXISTS wa_messages (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at timestamptz DEFAULT now(),
  phone text,
  sender_name text,
  body text,
  lead_id uuid REFERENCES leads(id) ON DELETE SET NULL,
  direction text CHECK (direction IN ('inbound','outbound')),
  timestamp timestamptz DEFAULT now(),
  read boolean DEFAULT false,
  is_ai boolean DEFAULT false
);

CREATE INDEX IF NOT EXISTS idx_wa_messages_lead_id ON wa_messages(lead_id);
CREATE INDEX IF NOT EXISTS idx_wa_messages_phone ON wa_messages(phone);
